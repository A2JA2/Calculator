﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void calcButton_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(numberOne.Text);
            double b = Convert.ToDouble(numberTwo.Text);

            if (mathsOperators.SelectedItem.ToString() == "+")
            {
                answerLabel.Text = (a + b).ToString();
            }

            else if (mathsOperators.SelectedItem.ToString() == "-")
            {
                answerLabel.Text = (a - b).ToString();
            }

            else if (mathsOperators.SelectedItem.ToString() == "/")
            {
                answerLabel.Text = (a / b).ToString();
            }

            else if (mathsOperators.SelectedItem.ToString() == "*")
            {
                answerLabel.Text = (a * b).ToString();
            }

            else if (mathsOperators.SelectedItem.ToString() == "")
            {
                MessageBox.Show("Please enter a valid maths operator");
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            mathsOperators.SelectedItem = "+";
            numberOne.Text = "0";
            numberTwo.Text = "0";
            answerLabel.Text = "...";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
