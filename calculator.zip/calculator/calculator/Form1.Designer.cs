﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calLayout = new System.Windows.Forms.TableLayoutPanel();
            this.mathsOperators = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.calcGroup = new System.Windows.Forms.GroupBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.numberTwo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numberOne = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.functionGroup = new System.Windows.Forms.GroupBox();
            this.answerLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.calLayout.SuspendLayout();
            this.calcGroup.SuspendLayout();
            this.functionGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // calLayout
            // 
            this.calLayout.ColumnCount = 2;
            this.calLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.28061F));
            this.calLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.71939F));
            this.calLayout.Controls.Add(this.mathsOperators, 0, 0);
            this.calLayout.Controls.Add(this.label1, 1, 0);
            this.calLayout.Controls.Add(this.calcGroup, 1, 1);
            this.calLayout.Controls.Add(this.functionGroup, 0, 1);
            this.calLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calLayout.Location = new System.Drawing.Point(0, 0);
            this.calLayout.Name = "calLayout";
            this.calLayout.RowCount = 2;
            this.calLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.14751F));
            this.calLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.85249F));
            this.calLayout.Size = new System.Drawing.Size(784, 461);
            this.calLayout.TabIndex = 0;
            // 
            // mathsOperators
            // 
            this.mathsOperators.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mathsOperators.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mathsOperators.FormattingEnabled = true;
            this.mathsOperators.Items.AddRange(new object[] {
            "+",
            "-",
            "/",
            "*"});
            this.mathsOperators.Location = new System.Drawing.Point(3, 3);
            this.mathsOperators.Name = "mathsOperators";
            this.mathsOperators.Size = new System.Drawing.Size(152, 33);
            this.mathsOperators.TabIndex = 0;
            this.mathsOperators.Text = "+";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(161, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(620, 56);
            this.label1.TabIndex = 1;
            this.label1.Text = "Calculator\r\nChoose a maths operator from the drop down menu on the left.\r\nEnter y" +
    "our number in the spaces below and click the calculator button for your answer.";
            // 
            // calcGroup
            // 
            this.calcGroup.Controls.Add(this.calcButton);
            this.calcGroup.Controls.Add(this.numberTwo);
            this.calcGroup.Controls.Add(this.label3);
            this.calcGroup.Controls.Add(this.numberOne);
            this.calcGroup.Controls.Add(this.label2);
            this.calcGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calcGroup.Location = new System.Drawing.Point(161, 59);
            this.calcGroup.Name = "calcGroup";
            this.calcGroup.Size = new System.Drawing.Size(620, 399);
            this.calcGroup.TabIndex = 2;
            this.calcGroup.TabStop = false;
            this.calcGroup.Text = "Calculate";
            // 
            // calcButton
            // 
            this.calcButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.calcButton.Location = new System.Drawing.Point(3, 102);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(614, 23);
            this.calcButton.TabIndex = 4;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // numberTwo
            // 
            this.numberTwo.Dock = System.Windows.Forms.DockStyle.Top;
            this.numberTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberTwo.Location = new System.Drawing.Point(3, 72);
            this.numberTwo.Name = "numberTwo";
            this.numberTwo.Size = new System.Drawing.Size(614, 30);
            this.numberTwo.TabIndex = 3;
            this.numberTwo.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Location = new System.Drawing.Point(3, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter your second number here:";
            // 
            // numberOne
            // 
            this.numberOne.Dock = System.Windows.Forms.DockStyle.Top;
            this.numberOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberOne.Location = new System.Drawing.Point(3, 29);
            this.numberOne.Name = "numberOne";
            this.numberOne.Size = new System.Drawing.Size(614, 30);
            this.numberOne.TabIndex = 1;
            this.numberOne.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(3, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter your first number here:";
            // 
            // functionGroup
            // 
            this.functionGroup.Controls.Add(this.answerLabel);
            this.functionGroup.Controls.Add(this.resetButton);
            this.functionGroup.Controls.Add(this.exitButton);
            this.functionGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.functionGroup.Location = new System.Drawing.Point(3, 59);
            this.functionGroup.Name = "functionGroup";
            this.functionGroup.Size = new System.Drawing.Size(152, 399);
            this.functionGroup.TabIndex = 3;
            this.functionGroup.TabStop = false;
            this.functionGroup.Text = "Function";
            // 
            // answerLabel
            // 
            this.answerLabel.AutoSize = true;
            this.answerLabel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.answerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerLabel.Location = new System.Drawing.Point(3, 325);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(27, 25);
            this.answerLabel.TabIndex = 2;
            this.answerLabel.Text = "...";
            // 
            // resetButton
            // 
            this.resetButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.resetButton.Location = new System.Drawing.Point(3, 350);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(146, 23);
            this.resetButton.TabIndex = 1;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.exitButton.Location = new System.Drawing.Point(3, 373);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(146, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.calLayout);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.calLayout.ResumeLayout(false);
            this.calLayout.PerformLayout();
            this.calcGroup.ResumeLayout(false);
            this.calcGroup.PerformLayout();
            this.functionGroup.ResumeLayout(false);
            this.functionGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel calLayout;
        private System.Windows.Forms.ComboBox mathsOperators;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox calcGroup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox numberOne;
        private System.Windows.Forms.TextBox numberTwo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.GroupBox functionGroup;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label answerLabel;
    }
}

